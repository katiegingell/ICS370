package com.example.demo;

public class UserRepo {
    public static User currentUser = null;

    public static Flight selectedFlight = null;
}